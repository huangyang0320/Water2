HLS-demo
========

> 一个简单的HLS视频播放例子，使用了MediaElement.js。